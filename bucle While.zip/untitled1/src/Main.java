
public class Main {

    public static void main(String[] args) {


        int numeroWhile = -4;

        while (numeroWhile < 3) {
            System.out.println(numeroWhile);
            numeroWhile = numeroWhile + 1;
        }


    }

}