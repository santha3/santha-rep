// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {

        int numeroif = -1;

        if (numeroif == 1) {
            System.out.println("es positivo");
        }else if (numeroif == 0) {
            System.out.println("es neutral");
        }else if (numeroif == -1){
                System.out.println("es negativo");
                }

            }




        }

