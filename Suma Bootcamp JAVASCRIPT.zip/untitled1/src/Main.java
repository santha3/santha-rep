import java.util.ArrayList;
public class Main {

    public static void main(String[] args) {
        int a;
        int b;
        int c;
        suma(a= 10, b= 15, c= 20);

    }
        public static int suma (int a, int b, int c) {
        int resultado = a + b + c;

        System.out.println(resultado);

            return resultado;
        }
    }
