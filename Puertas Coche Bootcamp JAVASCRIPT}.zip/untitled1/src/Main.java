import java.util.ArrayList;
public class Main {

    public static void main(String[] args) {
        Coche miCoche = new Coche();
        miCoche.AgregarPuerta();
        miCoche.AgregarPuerta();
        miCoche.AgregarPuerta();
        System.out.print(miCoche.puertas);

    }

    public static int suma(int a, int b, int c) {
        return 0;
    }
}
class Coche {
    public int puertas = 2;

    public void AgregarPuerta() {
        this.puertas++;
    }
}